# Landslide Monitor — frontend

Plain HTML, CSS and JavaScript (ES modules). No build step, no dependencies.

## Run
```bash
# 1. backend (from ../backend)
uvicorn main:app --reload            # http://localhost:8000

# 2. frontend (from this folder) — any static server works
python -m http.server 5173           # http://localhost:5173
```
Open http://localhost:5173. (Opening index.html straight from disk will not work: browsers block ES modules on file://.)

## Configure
Edit `config.js`:
| Key | Purpose | Default |
|---|---|---|
| `API_URL` | Backend base URL, no trailing slash | `http://localhost:8000` |
| `POLL_MS` | Overview refresh interval | `2000` |
| `STALE_AFTER_MS` | Age after which sensors are shown as quiet | `20000` |

To deploy separately, host this folder on any static host and replace `config.js`. The backend must allow your frontend's origin
(it currently allows all origins; restrict `allow_origins` in `backend/main.py` for production).

## Backend endpoints used
`GET /` · `GET /api/risk/current` · `GET /api/risk/history` · `GET /api/sensors/recent` · `GET /api/alerts/` ·
`POST /api/alerts/{id}/acknowledge` · `POST /api/ai/explain`

## Structure
```
index.html, config.js
css/styles.css
js/main.js                  hash router (#/ and #/history)
js/api/client.js            fetch, timeout, error → friendly message
js/api/endpoints.js         one function per backend endpoint
js/lib/                     dom helpers, formatting, risk vocabulary
js/components/              Header, MetricCard, StatusBadge, RiskGauge, RiskChart,
                            AlertsPanel, ExplainPanel, HistoryTable, states (Loading/Error/Empty)
js/views/                   Overview, History
```

## Keep in sync with the backend
Sensor limit markers in `js/lib/risk.js` mirror the thresholds in `backend/config/settings.py`; the API does not expose them.
