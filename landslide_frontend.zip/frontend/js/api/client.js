/* Single place that talks to the network. Everything else uses endpoints.js. */

const cfg = window.APP_CONFIG || {};
const BASE = String(cfg.API_URL || "").replace(/\/+$/, "");

export class ApiError extends Error {
  /** @param {"network"|"timeout"|"http"|"invalid"|"rejected"} kind */
  constructor(kind, status, message) {
    super(message);
    this.name = "ApiError";
    this.kind = kind;
    this.status = status;
  }
}

const MESSAGES = {
  network: "Can't reach the monitoring server. Check that the backend is running and that the API address in config.js is correct.",
  timeout: "The server took too long to respond. Try again.",
  invalid: "The server sent a response this app couldn't read.",
  notFound: "That item no longer exists.",
  server: "The server hit a problem while handling this request. Try again in a moment.",
  rejected: "The server rejected this request.",
};

/**
 * @param {string} path  e.g. "/api/risk/current"
 * @param {{method?: string, timeoutMs?: number}} [opts]
 */
export async function request(path, { method = "GET", timeoutMs = 10000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(BASE + path, { method, signal: controller.signal, headers: { Accept: "application/json" } });
  } catch (err) {
    if (err && err.name === "AbortError") throw new ApiError("timeout", 0, MESSAGES.timeout);
    throw new ApiError("network", 0, MESSAGES.network);
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    if (res.status === 404) throw new ApiError("http", 404, MESSAGES.notFound);
    if (res.status >= 500) throw new ApiError("http", res.status, MESSAGES.server);
    throw new ApiError("rejected", res.status, MESSAGES.rejected);
  }
  try {
    return await res.json();
  } catch {
    throw new ApiError("invalid", res.status, MESSAGES.invalid);
  }
}

export const apiBaseUrl = BASE;
