/*
 * One function per backend endpoint (see backend/api/*.py).
 * The backend signals "nothing yet" and some failures with a 200 and a
 * `message` / `error` key; those are normalised here so views never see them.
 */
import { request, ApiError } from "./client.js";

export const getHealth = () => request("/", { timeoutMs: 4000 });

/** @returns {Promise<object|null>} null when no assessment exists yet */
export async function getCurrentRisk() {
  const data = await request("/api/risk/current");
  return data && data.risk_level ? data : null;
}

/** Newest first. */
export async function getRiskHistory(limit = 50) {
  const data = await request(`/api/risk/history?limit=${encodeURIComponent(limit)}`);
  return Array.isArray(data) ? data : [];
}

/** Newest first. */
export async function getRecentReadings(limit = 50) {
  const data = await request(`/api/sensors/recent?limit=${encodeURIComponent(limit)}`);
  return Array.isArray(data) ? data : [];
}

export async function getOpenAlerts() {
  const data = await request("/api/alerts/");
  return Array.isArray(data) ? data : [];
}

export async function acknowledgeAlert(id) {
  const data = await request(`/api/alerts/${encodeURIComponent(id)}/acknowledge`, { method: "POST" });
  if (data && data.error) throw new ApiError("http", 404, "That alert no longer exists.");
  return data;
}

/** Runs the multi-agent explanation for the latest assessment. Can take several seconds. */
export async function explainLatestRisk() {
  const data = await request("/api/ai/explain", { method: "POST", timeoutMs: 90000 });
  if (!data || data.error || !data.explanation) {
    throw new ApiError("http", 404, "There is no risk assessment to explain yet. Wait for the first reading and try again.");
  }
  return data;
}
