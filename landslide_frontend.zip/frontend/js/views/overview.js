import * as api from "../api/endpoints.js";
import { h, replaceContent } from "../lib/dom.js";
import { ageSeconds, formatDateTime, relativeAge, num } from "../lib/format.js";
import { SENSORS, levelLabel, ruleLabel } from "../lib/risk.js";
import { MetricCard } from "../components/metricCard.js";
import { RiskGauge } from "../components/riskGauge.js";
import { RiskChart } from "../components/riskChart.js";
import { StatusBadge } from "../components/statusBadge.js";
import { AlertsPanel } from "../components/alertsPanel.js";
import { ExplainPanel } from "../components/explainPanel.js";
import { ErrorState, EmptyState, Skeleton } from "../components/states.js";

const cfg = window.APP_CONFIG || {};
const POLL_MS = cfg.POLL_MS || 2000;
const STALE_MS = cfg.STALE_AFTER_MS || 20000;
const POINTS = 60;

export function OverviewView({ setStatus }) {
  const heroSlot = h("section", { class: "hero", "aria-labelledby": "page-title" }, Skeleton(4));
  const banner = h("p", { class: "banner", role: "status", hidden: true });
  const metricsList = h("dl", { class: "metrics" });
  const sensorsSection = h("section", { "aria-labelledby": "sensors-h" },
    h("h2", { id: "sensors-h", text: "Sensor readings" }),
    h("p", { class: "muted", id: "sensors-updated" }), metricsList);
  const chartSlot = h("div", {});
  const chartPanel = h("section", { class: "panel", "aria-labelledby": "chart-h" },
    h("h2", { id: "chart-h", text: "Risk score over time" }), chartSlot);
  const alerts = AlertsPanel({
    onAcknowledge: async (id) => { await api.acknowledgeAlert(id); state.alerts = state.alerts.filter((a) => a.id !== id); alerts.update(state.alerts); },
  });
  const explain = ExplainPanel({ onExplain: api.explainLatestRisk });

  const el = h("main", { id: "main", class: "container view", tabindex: "-1" },
    heroSlot, banner, sensorsSection,
    h("div", { class: "two-col" }, chartPanel, alerts.el),
    explain.el);

  const state = { loaded: false, alerts: [] };
  let timer = null, stopped = true, inFlight = false;

  function renderHero(risk) {
    if (!risk) {
      replaceContent(heroSlot,
        h("h1", { id: "page-title", text: "Landslide risk" }),
        EmptyState({ title: "Waiting for the first assessment", message: "The backend scores the slope every couple of seconds once sensor data arrives. If nothing appears, check that the backend is running and receiving readings." }));
      return;
    }
    const rules = Array.isArray(risk.triggered_rules) ? risk.triggered_rules : [];
    replaceContent(heroSlot,
      h("div", { class: "hero-main", "data-level": risk.risk_level },
        h("h1", { id: "page-title", text: "Landslide risk" }),
        h("p", { class: "level" }, StatusBadge(risk.risk_level)),
        h("p", { class: "score" }, h("strong", { text: num(risk.risk_score, 0) }), " out of 100"),
        RiskGauge(risk.risk_score),
        h("p", { class: "muted", text: `Rules ${num(risk.rule_score, 0)} · Model ${num(risk.model_score, 0)} · assessed ${formatDateTime(risk.timestamp)}` })),
      h("div", { class: "hero-side" },
        h("h2", { text: "What triggered this" }),
        rules.length
          ? h("ul", { class: "rule-list" }, rules.map((k) => h("li", { text: ruleLabel(k) })))
          : h("p", { class: "muted", text: `No thresholds crossed. The ${levelLabel(risk.risk_level).toLowerCase()} rating comes from the combined sensor model.` })));
  }

  function renderReadings(latest) {
    replaceContent(metricsList, SENSORS.map((sn) => MetricCard({ ...sn, value: latest ? latest[sn.key] : null })));
    el.querySelector("#sensors-updated").textContent = latest ? `Latest reading ${relativeAge(latest.timestamp)}.` : "No readings received yet.";
  }

  function apply({ risk, history, readings, alertList }) {
    renderHero(risk);
    const latest = readings[0] || null;
    renderReadings(latest);
    replaceContent(chartSlot, history.length ? RiskChart(history.slice().reverse()) :
      EmptyState({ title: "No history yet", message: "The chart fills in as assessments are recorded." }));
    state.alerts = alertList;
    alerts.update(alertList);

    const quiet = !latest || ageSeconds(latest.timestamp) * 1000 > STALE_MS;
    banner.hidden = !quiet;
    if (quiet) banner.textContent = latest
      ? `No new sensor readings for ${relativeAge(latest.timestamp).replace(" ago", "")}. Check the sensor board and its connection to the backend.`
      : "The backend is running but hasn't received any sensor readings yet.";
    setStatus(quiet ? "quiet" : "live");
  }

  async function poll() {
    if (stopped || inFlight) return;
    if (document.hidden) return schedule(POLL_MS * 3);
    inFlight = true;
    try {
      const [risk, history, readings, alertList] = await Promise.all([
        api.getCurrentRisk(), api.getRiskHistory(POINTS), api.getRecentReadings(1), api.getOpenAlerts(),
      ]);
      if (stopped) return;
      state.loaded = true;
      apply({ risk, history, readings, alertList });
    } catch (err) {
      if (stopped) return;
      setStatus("down");
      if (!state.loaded) {
        replaceContent(heroSlot, h("h1", { id: "page-title", text: "Landslide risk" }),
          ErrorState({ title: "Can't load monitoring data", message: err.message, onRetry: () => { replaceContent(heroSlot, Skeleton(4)); poll(); } }));
      } else {
        banner.hidden = false;
        banner.textContent = "Connection to the backend was lost. Showing the last data received and retrying.";
      }
    } finally {
      inFlight = false;
      schedule(POLL_MS);
    }
  }
  const schedule = (ms) => { clearTimeout(timer); if (!stopped) timer = setTimeout(poll, ms); };
  const onVisible = () => { if (!document.hidden && !stopped) { clearTimeout(timer); poll(); } };

  return {
    el,
    title: "Overview",
    start() { stopped = false; document.addEventListener("visibilitychange", onVisible); poll(); },
    stop() { stopped = true; clearTimeout(timer); document.removeEventListener("visibilitychange", onVisible); },
  };
}
