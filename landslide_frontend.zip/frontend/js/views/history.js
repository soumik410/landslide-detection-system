import * as api from "../api/endpoints.js";
import { h, replaceContent } from "../lib/dom.js";
import { LEVEL_KEYS, levelLabel } from "../lib/risk.js";
import { HistoryTable, historyToCsv } from "../components/historyTable.js";
import { ErrorState, EmptyState, LoadingState } from "../components/states.js";

export function HistoryView({ setStatus }) {
  let rows = [];
  let destroyed = false;

  const limit = h("select", { id: "limit" }, [50, 100, 200].map((n) => h("option", { value: n, text: `Last ${n}` })));
  const level = h("select", { id: "level" }, h("option", { value: "", text: "All levels" }),
    LEVEL_KEYS.map((k) => h("option", { value: k, text: levelLabel(k) })));
  const refresh = h("button", { type: "button", class: "btn", text: "Refresh" });
  const download = h("button", { type: "button", class: "btn", text: "Download CSV", disabled: true });
  const summary = h("p", { class: "muted", role: "status" });
  const slot = h("div", {});

  const el = h("main", { id: "main", class: "container view", tabindex: "-1" },
    h("h1", { id: "page-title", text: "Assessment history" }),
    h("p", { class: "muted", text: "Every risk assessment the backend has recorded, newest first." }),
    h("div", { class: "toolbar" },
      h("label", {}, "Show ", limit), h("label", {}, "Risk level ", level), refresh, download),
    summary, slot);

  const visible = () => (level.value ? rows.filter((r) => r.risk_level === level.value) : rows);

  function render() {
    const list = visible();
    download.disabled = !list.length;
    if (!rows.length) {
      summary.textContent = "";
      replaceContent(slot, EmptyState({ title: "No assessments yet", message: "Assessments are recorded automatically once the backend receives sensor readings. Open the overview to check that data is arriving.", action: { label: "Open overview", onClick: () => { location.hash = "#/"; } } }));
    } else if (!list.length) {
      summary.textContent = `0 of ${rows.length} assessments shown.`;
      replaceContent(slot, EmptyState({ title: "No matches", message: `None of the last ${rows.length} assessments were rated ${levelLabel(level.value)}. Choose another level or show more history.` }));
    } else {
      summary.textContent = `${list.length} of ${rows.length} assessments shown.`;
      replaceContent(slot, HistoryTable(list));
    }
  }

  async function load() {
    refresh.disabled = true;
    replaceContent(slot, LoadingState("Loading history…"));
    try {
      const data = await api.getRiskHistory(Number(limit.value));
      if (destroyed) return;
      rows = data;
      setStatus("live");
      render();
    } catch (err) {
      if (destroyed) return;
      setStatus("down");
      summary.textContent = "";
      replaceContent(slot, ErrorState({ title: "Couldn't load history", message: err.message, onRetry: load }));
    } finally {
      refresh.disabled = false;
    }
  }

  refresh.addEventListener("click", load);
  limit.addEventListener("change", load);
  level.addEventListener("change", render);
  download.addEventListener("click", () => {
    const blob = new Blob([historyToCsv(visible())], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = h("a", { href: url, download: "risk-assessments.csv" });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  return { el, title: "History", start: load, stop() { destroyed = true; } };
}
