import { Header } from "./components/header.js";
import { OverviewView } from "./views/overview.js";
import { HistoryView } from "./views/history.js";
import { h } from "./lib/dom.js";

const ROUTES = { "#/": OverviewView, "#/history": HistoryView };
const header = Header();
const app = document.getElementById("app");
app.append(header.el);
let outlet = h("div", { id: "outlet" });
app.append(outlet);
let current = null;

function navigate() {
  const hash = ROUTES[location.hash] ? location.hash : "#/";
  if (current) current.stop();
  header.setStatus("checking");
  current = ROUTES[hash]({ setStatus: header.setStatus });
  outlet.replaceChildren(current.el);
  header.setRoute(hash);
  document.title = `${current.title} · Landslide Monitor`;
  current.start();
  window.scrollTo(0, 0);
  if (navigate.count++) current.el.focus({ preventScroll: true }); // move focus to new page after in-app navigation
}
navigate.count = 0;

window.addEventListener("hashchange", navigate);
navigate();
