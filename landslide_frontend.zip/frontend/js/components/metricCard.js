import { h } from "../lib/dom.js";
import { num } from "../lib/format.js";

/** One sensor reading, with its rule limit marked on a small scale when the backend has one. */
export function MetricCard({ label, unit, value, decimals, max, limit }) {
  const hasValue = typeof value === "number" && Number.isFinite(value);
  const over = hasValue && limit != null && value >= limit;
  const glue = (u) => (u === "%" || u === "°" ? u : u ? " " + u : "");
  const shown = `${num(value, decimals)}${hasValue ? glue(unit) : ""}`;
  const limitText = `${limit}${glue(unit)}`;

  const card = h("div", { class: "metric", "data-over": over ? "true" : "false" },
    h("dt", { class: "metric-label", text: label }),
    h("dd", { class: "metric-value", text: shown }));

  if (limit != null) {
    const pct = (v) => `${Math.max(0, Math.min(100, (v / max) * 100))}%`;
    const summary = !hasValue
      ? `${label}: no reading`
      : `${label} ${shown}, limit ${limitText}, ${over ? "above" : "within"} limit`;
    card.append(
      h("div", { class: "scale", role: "img", "aria-label": summary },
        h("span", { class: "scale-fill", style: `width:${hasValue ? pct(value) : "0%"}` }),
        h("span", { class: "scale-limit", style: `left:${pct(limit)}` })),
      h("p", { class: "metric-note", text: !hasValue ? "No reading" : over ? `Above limit (${limitText})` : `Within limit (${limitText})` }));
  } else {
    card.append(h("p", { class: "metric-note", text: "Monitored, no alert limit" }));
  }
  return card;
}
