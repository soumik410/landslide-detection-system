import { h } from "../lib/dom.js";
import { LEVEL_KEYS, levelLabel } from "../lib/risk.js";

/* 0–100 scale in four bands matching backend/risk/fusion.py classify(): 25 / 50 / 75. HTML, so text stays readable at any width. */
export function RiskGauge(score) {
  const hasScore = typeof score === "number" && Number.isFinite(score);
  const pos = hasScore ? Math.max(0, Math.min(100, score)) : null;
  return h("div", { class: "gauge", role: "img", "aria-label": hasScore ? `Risk score ${score} out of 100` : "Risk score not available" },
    h("div", { class: "gauge-bands" }, LEVEL_KEYS.map((k, i) =>
      h("div", { class: "gauge-band", "data-level": k },
        h("span", { class: "gauge-label", text: levelLabel(k) }),
        h("span", { class: "gauge-range", text: `${i * 25}–${i === 3 ? 100 : i * 25 + 24}` })))),
    pos != null && h("span", { class: "gauge-marker", style: `left:${pos}%` }));
}
