import { s, h } from "../lib/dom.js";
import { formatTime } from "../lib/format.js";
import { LEVEL_KEYS } from "../lib/risk.js";

/** Risk score over time. `rows` must be oldest → newest. Shapes are SVG; labels and the end dot are HTML so nothing distorts. */
export function RiskChart(rows) {
  const pts = rows.filter((r) => typeof r.risk_score === "number");
  const X = (i) => (pts.length === 1 ? 50 : (i / (pts.length - 1)) * 100);
  const Y = (v) => 100 - Math.max(0, Math.min(100, v));

  const svg = s("svg", { viewBox: "0 0 100 100", preserveAspectRatio: "none", class: "chart-svg", "aria-hidden": "true", focusable: "false" });
  LEVEL_KEYS.forEach((k, i) => svg.append(s("rect", { x: 0, y: Y((i + 1) * 25), width: 100, height: 25, class: "chart-band", "data-level": k })));
  [25, 50, 75].forEach((v) => svg.append(s("line", { x1: 0, x2: 100, y1: Y(v), y2: Y(v), class: "chart-grid" })));

  let summary = "No risk history yet.";
  let dot = null;
  if (pts.length) {
    svg.append(s("path", { d: pts.map((r, i) => `${i ? "L" : "M"}${X(i).toFixed(2)} ${Y(r.risk_score).toFixed(2)}`).join(" "), class: "chart-line" }));
    const last = pts[pts.length - 1];
    const scores = pts.map((r) => r.risk_score);
    dot = h("span", { class: "chart-dot", style: `left:${X(pts.length - 1)}%;top:${Y(last.risk_score)}%` });
    summary = `Risk score over the last ${pts.length} assessments: latest ${last.risk_score}, lowest ${Math.min(...scores)}, highest ${Math.max(...scores)}.`;
  }

  const ticks = [100, 75, 50, 25, 0].map((v) => h("span", { class: "chart-tick", style: `top:${Y(v)}%`, text: String(v) }));
  const first = pts[0], last = pts[pts.length - 1];
  return h("figure", { class: "chart" },
    h("div", { class: "chart-frame", role: "img", "aria-label": summary },
      h("div", { class: "chart-ticks" }, ticks),
      h("div", { class: "chart-plot" }, svg, dot)),
    h("figcaption", { class: "chart-axis" },
      h("span", { text: first ? formatTime(first.timestamp) : "" }),
      h("span", { text: last ? formatTime(last.timestamp) : "" })));
}
