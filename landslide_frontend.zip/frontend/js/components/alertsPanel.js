import { h } from "../lib/dom.js";
import { formatDateTime } from "../lib/format.js";
import { StatusBadge } from "./statusBadge.js";
import { EmptyState } from "./states.js";

const VISIBLE = 5;

/**
 * Open (unacknowledged) alerts. The backend raises one every cycle while risk stays High/Severe,
 * so the list is capped and can be expanded or cleared in one go. It re-renders only when the set
 * of alerts changes, and puts keyboard focus back on the same control afterwards.
 */
export function AlertsPanel({ onAcknowledge }) {
  const count = h("span", { class: "count", text: "0" });
  const message = h("p", { class: "inline-error", role: "alert", hidden: true });
  const tools = h("div", { class: "alert-tools", hidden: true });
  const list = h("ul", { class: "alert-list" });
  const el = h("section", { class: "panel", "aria-labelledby": "alerts-h" },
    h("h2", { id: "alerts-h" }, "Open alerts ", count), message, tools, list);

  let signature = null, current = [], expanded = false, busy = false;

  function fail(err) { message.textContent = err.message; message.hidden = false; }

  async function ackOne(id) {
    message.hidden = true;
    try { await onAcknowledge(id); } catch (err) { fail(err); }
  }

  async function ackAll() {
    busy = true; message.hidden = true; render(true);
    try {
      for (const a of current.slice()) await onAcknowledge(a.id); // one real request per alert; the backend has no bulk endpoint
    } catch (err) { fail(err); }
    busy = false; render(true);
  }

  function render(force) {
    const focusKey = list.contains(document.activeElement) || tools.contains(document.activeElement) ? document.activeElement.dataset.focusKey : null;
    count.textContent = String(current.length);
    list.replaceChildren(); tools.replaceChildren();
    tools.hidden = current.length <= 1;
    if (!current.length) {
      list.append(h("li", {}, EmptyState({ title: "No open alerts", message: "An alert is raised when the risk level reaches High or Severe." })));
      return;
    }
    if (current.length > 1) {
      tools.append(h("button", { type: "button", class: "btn btn-small", "data-focus-key": "all", disabled: busy, onclick: ackAll, text: busy ? "Acknowledging…" : `Acknowledge all ${current.length}` }));
    }
    const shown = expanded ? current : current.slice(0, VISIBLE);
    for (const a of shown) {
      list.append(h("li", { class: "alert-item" },
        h("div", { class: "alert-meta" }, StatusBadge(a.risk_level), h("time", { text: formatDateTime(a.timestamp) })),
        h("p", { text: a.message }),
        h("button", { type: "button", class: "btn btn-small", "data-focus-key": `ack-${a.id}`, disabled: busy, "aria-label": `Acknowledge alert from ${formatDateTime(a.timestamp)}`, onclick: () => ackOne(a.id), text: "Acknowledge" })));
    }
    if (current.length > VISIBLE) {
      list.append(h("li", { class: "alert-more" }, h("button", { type: "button", class: "btn btn-small", "data-focus-key": "more", "aria-expanded": String(expanded),
        onclick: () => { expanded = !expanded; render(true); }, text: expanded ? "Show fewer" : `Show all ${current.length}` })));
    }
    if (focusKey) {
      const target = el.querySelector(`[data-focus-key="${focusKey}"]`) || el.querySelector('[data-focus-key="all"]');
      if (target) target.focus({ preventScroll: true });
    }
  }

  function update(alerts) {
    const sig = alerts.map((a) => a.id).join(",");
    if (sig === signature) return;
    signature = sig; current = alerts;
    render();
  }
  return { el, update };
}
