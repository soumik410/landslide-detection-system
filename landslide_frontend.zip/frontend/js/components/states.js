import { h } from "../lib/dom.js";

export function LoadingState(label = "Loading…") {
  return h("div", { class: "state state-loading", role: "status" },
    h("span", { class: "spinner", "aria-hidden": "true" }),
    h("p", { text: label }));
}

export function Skeleton(lines = 3) {
  const wrap = h("div", { class: "skeleton", "aria-hidden": "true" });
  for (let i = 0; i < lines; i++) wrap.append(h("span", { class: "skeleton-line" }));
  return wrap;
}

export function ErrorState({ title = "Something went wrong", message, onRetry }) {
  return h("div", { class: "state state-error", role: "alert" },
    h("h2", { text: title }),
    h("p", { text: message }),
    onRetry && h("button", { type: "button", class: "btn", onclick: onRetry, text: "Try again" }));
}

export function EmptyState({ title, message, action }) {
  return h("div", { class: "state state-empty" },
    h("h2", { text: title }),
    h("p", { text: message }),
    action && h("button", { type: "button", class: "btn", onclick: action.onClick, text: action.label }));
}
