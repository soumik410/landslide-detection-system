import { h, s } from "../lib/dom.js";
import { levelLabel } from "../lib/risk.js";

/* Each level has its own glyph so status never relies on colour alone. */
const GLYPHS = {
  LOW: () => s("circle", { cx: 8, cy: 8, r: 5, fill: "none", stroke: "currentColor", "stroke-width": 2 }),
  MODERATE: () => s("path", { d: "M8 2.5 14 13H2Z", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linejoin": "round" }),
  HIGH: () => s("path", { d: "M8 2 14 13H2Z", fill: "currentColor" }),
  SEVERE: () => s("rect", { x: 3, y: 3, width: 10, height: 10, fill: "currentColor", transform: "rotate(45 8 8)" }),
};

export function StatusBadge(level) {
  const glyph = GLYPHS[level] ? GLYPHS[level]() : s("circle", { cx: 8, cy: 8, r: 3, fill: "currentColor" });
  return h("span", { class: "badge", "data-level": level || "UNKNOWN" },
    s("svg", { viewBox: "0 0 16 16", width: 14, height: 14, "aria-hidden": "true", focusable: "false" }, glyph),
    h("span", { text: levelLabel(level) }));
}
