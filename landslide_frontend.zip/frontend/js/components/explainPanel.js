import { h } from "../lib/dom.js";
import { AGENT_LABELS } from "../lib/risk.js";
import { LoadingState, ErrorState } from "./states.js";

/* The backend embeds "[xyz_agent unavailable: <raw error>]" in text when the AI service fails. Never show that. */
const UNAVAILABLE = /\[[a-z_]+ unavailable:[^\]]*\]/gi;
const hadFailure = (t) => typeof t === "string" && /\[[a-z_]+ unavailable:/i.test(t);
const clean = (t) => (typeof t === "string" ? t.replace(UNAVAILABLE, "").trim() : "");

export function ExplainPanel({ onExplain }) {
  const button = h("button", { type: "button", class: "btn btn-primary", text: "Explain latest assessment" });
  const output = h("div", { class: "explain-out", "aria-live": "polite" });
  const el = h("section", { class: "panel", "aria-labelledby": "explain-h" },
    h("div", { class: "explain-head" },
      h("div", {},
        h("h2", { id: "explain-h", text: "Why is the risk at this level?" }),
        h("p", { class: "muted", text: "Asks the analysis agents to explain the latest assessment using sensor trends, geology notes and past landslide records. This can take several seconds." })),
      button),
    output);

  async function run() {
    button.disabled = true;
    output.replaceChildren(LoadingState("Generating explanation…"));
    try {
      const r = await onExplain();
      output.replaceChildren(render(r));
    } catch (err) {
      output.replaceChildren(ErrorState({ title: "Couldn't generate an explanation", message: err.message, onRetry: run }));
    } finally {
      button.disabled = false;
    }
  }
  button.addEventListener("click", run);

  function render(r) {
    const notes = Object.entries(r.sub_agent_notes || {});
    const degraded = hadFailure(r.explanation) || notes.some(([, t]) => hadFailure(t));
    const text = clean(r.explanation);
    const body = h("div", {});
    if (degraded) {
      body.append(h("p", { class: "notice", role: "note", text: "The AI explanation service was unavailable, so this summary is based only on the rule results. Check the backend's GROQ_API_KEY and network access." }));
    }
    body.append(h("p", { class: "explanation", text: text || "No explanation text was returned." }));
    const usable = notes.filter(([, t]) => !hadFailure(t) && clean(t));
    if (usable.length) {
      body.append(h("h3", { text: "Supporting notes" }),
        h("dl", { class: "notes" }, usable.map(([k, t]) => [h("dt", { text: AGENT_LABELS[k] || k }), h("dd", { text: clean(t) })])));
    }
    return body;
  }
  return { el };
}
