import { h } from "../lib/dom.js";
import { formatDateTime, num } from "../lib/format.js";
import { ruleLabel } from "../lib/risk.js";
import { StatusBadge } from "./statusBadge.js";

/** Risk assessment history. Each row can expand to show how the score was made. */
export function HistoryTable(rows) {
  const tbody = h("tbody");
  for (const r of rows) {
    const detailId = `assessment-${r.id}`;
    const toggle = h("button", { type: "button", class: "btn btn-small", "aria-expanded": "false", "aria-controls": detailId, "aria-label": `Details for assessment ${r.id}`, text: "Details" });
    const rules = Array.isArray(r.triggered_rules) ? r.triggered_rules : [];
    const detail = h("tr", { id: detailId, class: "detail-row", hidden: true },
      h("td", { colspan: 7 },
        h("div", { class: "detail" },
          h("p", {}, h("strong", { text: "Rule score " }), num(r.rule_score, 1), " · ", h("strong", { text: "Model score " }), num(r.model_score, 1), " · ", h("strong", { text: "Combined " }), num(r.risk_score, 1)),
          rules.length
            ? h("ul", {}, rules.map((k) => h("li", { text: ruleLabel(k) })))
            : h("p", { class: "muted", text: "No rule thresholds were crossed." }))));
    toggle.addEventListener("click", () => {
      const open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      detail.hidden = open;
    });
    tbody.append(
      h("tr", {},
        h("th", { scope: "row", text: `#${r.id}` }),
        h("td", {}, h("time", { text: formatDateTime(r.timestamp) })),
        h("td", {}, StatusBadge(r.risk_level)),
        h("td", { class: "num", text: num(r.risk_score, 1) }),
        h("td", { class: "num", text: String(Array.isArray(r.triggered_rules) ? r.triggered_rules.length : 0) }),
        h("td", { text: r.has_explanation ? "Yes" : "No" }),
        h("td", {}, toggle)),
      detail);
  }
  const table = h("table", { class: "table" },
    h("caption", { class: "sr-only", text: "Risk assessments, newest first" }),
    h("thead", {}, h("tr", {}, ["ID", "Time", "Risk level", "Score", "Rules triggered", "Explained", "Actions"].map((t) =>
      h("th", { scope: "col", class: t === "Score" || t === "Rules triggered" ? "num" : null, text: t })))),
    tbody);
  return h("div", { class: "table-wrap", tabindex: "0", role: "region", "aria-label": "Risk assessment history table (scrolls horizontally on small screens)" }, table);
}

/** CSV of exactly what the API returned; built in the browser, no extra endpoint needed. */
export function historyToCsv(rows) {
  const head = ["id", "timestamp_utc", "risk_level", "risk_score", "rule_score", "model_score", "triggered_rules", "has_explanation"];
  const esc = (v) => {
    let t = v == null ? "" : String(v);
    if (/^[=+\-@\t\r]/.test(t)) t = "'" + t; // guard against spreadsheet formula injection
    return /[",\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t;
  };
  const lines = rows.map((r) => [r.id, r.timestamp, r.risk_level, r.risk_score, r.rule_score, r.model_score,
    Array.isArray(r.triggered_rules) ? r.triggered_rules.join(";") : "", r.has_explanation ? "yes" : "no"].map(esc).join(","));
  return [head.join(","), ...lines].join("\n");
}
