import { h, s } from "../lib/dom.js";

const LINKS = [{ hash: "#/", label: "Overview" }, { hash: "#/history", label: "History" }];

const STATUS = {
  checking: { text: "Connecting", cls: "checking" },
  live: { text: "Live", cls: "live" },
  quiet: { text: "Connected, sensors quiet", cls: "quiet" },
  down: { text: "Backend unreachable", cls: "down" },
};

export function Header() {
  const dot = h("span", { class: "status-dot", "aria-hidden": "true" });
  const label = h("span", { text: "Connecting" });
  const status = h("p", { class: "system-status", role: "status", "data-state": "checking" }, dot, label);
  const nav = h("nav", { "aria-label": "Main" }, h("ul", {}, LINKS.map((l) =>
    h("li", {}, h("a", { href: l.hash, "data-hash": l.hash, text: l.label })))));

  const mark = s("svg", { viewBox: "0 0 24 24", width: 24, height: 24, "aria-hidden": "true", focusable: "false" },
    s("path", { d: "M2 20 12 4l10 16Z", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linejoin": "round" }),
    s("path", { d: "M8 20l4-7 4 7", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linejoin": "round" }));

  const el = h("header", { class: "site-header" },
    h("div", { class: "container header-inner" },
      h("a", { class: "brand", href: "#/" }, mark, h("span", { text: "Landslide Monitor" })),
      nav, status));

  return {
    el,
    setRoute(hash) {
      el.querySelectorAll("a[data-hash]").forEach((a) => {
        if (a.dataset.hash === hash) a.setAttribute("aria-current", "page");
        else a.removeAttribute("aria-current");
      });
    },
    setStatus(key) {
      const st = STATUS[key] || STATUS.checking;
      status.dataset.state = st.cls;
      label.textContent = st.text;
    },
  };
}
