/*
 * Deploy-time configuration. Edit this file (or replace it at deploy time)
 * to point the frontend at a different backend. No secrets belong here.
 */
window.APP_CONFIG = {
  // Base URL of the FastAPI backend, without a trailing slash.
  API_URL: "http://localhost:8000",
  // How often the overview refreshes. The backend produces a reading every 2 s.
  POLL_MS: 2000,
  // If the newest sensor reading is older than this, the UI reports the sensors as quiet.
  STALE_AFTER_MS: 20000,
};
